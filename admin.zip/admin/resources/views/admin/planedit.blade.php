@extends('admin.layouts.layout')
@section('content')

<style>
    input[type=radio] {
        /*display: none; */
    }

    input[type="radio"]:checked + label {
        background: #31A9EE;
        color: #ffffff; 
    }

    .label:hover {
        background-color: #E2EDF9; 
    }

    .used_time{
        width:60px;
        text-align: left;
    }
</style>

<!-- Example DataTables Card-->
<div class="card mb-3">
    <form action="{{ url('plan/update') }}/{{ $plan->id }}" method="get">
        @csrf
        <div class="card-header">
            <i class="fa fa-table"></i>予約</div>
            <div class="card-body">
                <div class="form-group">
                    <label>ユーザー名</label>
                    <p>
                        <select name="user_id" class="form-control">
                            <?php foreach ($users as $k => $v){ ?>
                                <option value="{{ $v->id }}" @if($plan->client_id == $v->id) selected="selected" @endif>{{ $v->name }}</option>
                            <?php } ?>          
                        </select>
                    </p>
                    <!--  <input type="" class="form-control" id="user-name">-->
                </div>

                <div class="form-group">
                    <label>メニュー</label>
                    <br>

                    <p>
                        <select name="services_id" class="form-control">
                            <?php foreach ($services as $k => $v){ ?>
                                <option value="{{ $v->id }}" @if($plan->services_id == $v->id) selected="selected" @endif>{{ $v->name }}</option>
                            <?php } ?>          
                        </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>スタッフ</label>
                    <br>

                    <p>
                        <select name="staffs_id" class="form-control">
                            <?php foreach ($staffs as $k => $v){ ?>
                                <option value="{{ $v->id }}" @if($plan->provider_id == $v->id) selected="selected" @endif>{{ $v->name }}</option>
                            <?php } ?>          
                        </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>予約日時</label>
                    <input id="used_at" name="used_at" type="date" value="{{ $plan->used_at }}">
                </div>

                <div class="form-group">
                    <label>予約時間</label>
                <!--
   
                    <label><input type="radio" name="timezone">昼の時間帯</label>
                    <label><input type="radio" name="timezone">夕方～夜の時間帯</label>
                -->
                <label><input name="open_used_time" id="open_used_time" type="hidden" value=""></label>
                <label><input name="close_used_time" id="close_used_time" type="hidden" value=""></label>

                <div id="shop_hours"></div>
                <br>
<!--
                    <label><input name="used_time" type="radio" value="10:00" @if($plan->used_time == "10:00") checked="checked" @endif >10:00</label>
                    <label><input name="used_time" type="radio" value="10:30" @if($plan->used_time == "10:30") checked="checked" @endif >10:30</label>
                    <label><input name="used_time" type="radio" value="11:00" @if($plan->used_time == "11:00") checked="checked" @endif >11:00</label>
                    <label><input name="used_time" type="radio" value="11:30" @if($plan->used_time == "11:30") checked="checked" @endif >11:30</label>
                    <label><input name="used_time" type="radio" value="12:00" @if($plan->used_time == "12:00") checked="checked" @endif >12:00</label>
                    <label><input name="used_time" type="radio" value="12:30" @if($plan->used_time == "12:30") checked="checked" @endif >12:30</label>
                    <br>
                    <label><input name="used_time" type="radio" value="13:00" @if($plan->used_time == "13:00") checked="checked" @endif >13:00</label>
                    <label><input name="used_time" type="radio" value="13:30" @if($plan->used_time == "13:30") checked="checked" @endif >13:30</label>
                    <label><input name="used_time" type="radio" value="14:00" @if($plan->used_time == "14:00") checked="checked" @endif >14:00</label>
                    <label><input name="used_time" type="radio" value="14:30" @if($plan->used_time == "14:30") checked="checked" @endif >14:30</label>
                    <label><input name="used_time" type="radio" value="15:00" @if($plan->used_time == "15:00") checked="checked" @endif >15:00</label>
                    <label><input name="used_time" type="radio" value="15:30" @if($plan->used_time == "15:30") checked="checked" @endif >15:30</label>
                    <br>
                    <input name="used_time" type="radio" value="16:00" @if($plan->used_time == "16:00") checked="checked" @endif>16:00
                    <input name="used_time" type="radio" value="16:30" @if($plan->used_time == "16:30") checked="checked" @endif>16:30
                    <input name="used_time" type="radio" value="17:00" @if($plan->used_time == "17:00") checked="checked" @endif>17:00
                    <input name="used_time" type="radio" value="17:30" @if($plan->used_time == "17:30") checked="checked" @endif>17:30
                    <input name="used_time" type="radio" value="18:00" @if($plan->used_time == "18:00") checked="checked" @endif>18:00
                    <input name="used_time" type="radio" value="18:30" @if($plan->used_time == "18:30") checked="checked" @endif>18:30
<br>
                    <input name="used_time" type="radio" value="19:00" @if($plan->used_time == "19:00") checked="checked" @endif>19:00
                    <input name="used_time" type="radio" value="19:30" @if($plan->used_time == "19:30") checked="checked" @endif>19:30
                    <input name="used_time" type="radio" value="20:00" @if($plan->used_time == "20:00") checked="checked" @endif>20:00
                    <input name="used_time" type="radio" value="20:30" @if($plan->used_time == "20:30") checked="checked" @endif>20:30
                    <input name="used_time" type="radio" value="21:30" @if($plan->used_time == "21:00") checked="checked" @endif>21:00
                    <input name="used_time" type="radio" value="21:30" @if($plan->used_time == "21:30") checked="checked" @endif>21:30
                -->
            </div>

            <button type="submit" class="btn btn-success" onclick="saveData()">作成する</button>
        </form>
    </div>
</div>

<script type="text/javascript">
    document.getElementById("used_at").onchange = function(){ 
        $.ajax({
            type: 'GET',
            url: "{{url ('plan/scheduleByDayJson/')}}/{{$plan->provider_id}}/"+document.getElementById("used_at").value,
            dataType: 'json'
        })
        .done( function(data) {
            html = "";
            html += "<label><input class='used_time' name='used_time' type='radio' value='" + "02"+ ":30'>" + "02" +":30</label>" ;

            document.getElementById("shop_hours").innerHTML = html;
        })
        .always(function(data){
        });

        var date = new Date(document.getElementById("used_at").value);
        var day = date.toDateString();

        var week_open_hours = [];
        var week_close_hours = [];

/*

        <?php foreach ($openhours as $i => $week) { ?>

            var opentime_<?php echo $i;?> = '<?php echo $week['open'];?>';

            count = 0;
            if(/pm/.exec(opentime_<?php echo $i;?>) != null){
             count = 12 ; 
             }

         opentime_<?php echo $i;?> = opentime_<?php echo $i;?>.replace('am', '');
         opentime_<?php echo $i;?> = opentime_<?php echo $i;?>.replace('pm', '');

         var date2 = new Date(day + ' ' + opentime_<?php echo $i;?>);

         w = date2.setHours(date2.getHours() + count);

         week_open_hours[<?php echo $i;?>] = date2.toLocaleTimeString();

         var closetime_<?php echo $i;?> = '<?php echo $week['close'];?>';

         count = 0;
         if(/pm/.exec(closetime_<?php echo $i;?>) != null){
             count = 12 ; 
         }

         closetime_<?php echo $i;?> = closetime_<?php echo $i;?>.replace('am', '');
         closetime_<?php echo $i;?> = closetime_<?php echo $i;?>.replace('pm', '');

         var date2 = new Date(day + ' ' + closetime_<?php echo $i;?>);
         w = date2.setHours(date2.getHours() + count);
         week_close_hours[<?php echo $i;?>] = date2.toLocaleTimeString();
     <?php } ?>
*/
     var date2 = new Date(day+' '+ closetime_<?php echo $i;?>);
     w = date2.setHours(date2.getHours() + count);

/*
     document.getElementById("open_used_time").value = week_open_hours[date.getDay()+1];
     document.getElementById("close_used_time").value = week_close_hours[date.getDay()+1];


     var opentimedate = new Date(day+' '+document.getElementById("open_used_time").value);

     var closetimedate = new Date(day+' '+document.getElementById("close_used_time").value);


     var html = "";

     for(var t = 0; t < 24; t++){
        if( t >= opentimedate.getHours() && t <= closetimedate.getHours()){
            if(t == opentimedate.getHours() && opentimedate.getMinutes() != 30) {
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>"  ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>"  ;

            } else if( t == opentimedate.getHours() ){

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;

            }else if(t == closetimedate.getHours() && closetimedate.getMinutes() != 30) {

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>";

            }else if(t == closetimedate.getHours() && closetimedate.getMinutes() == 30) {

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>" ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;
            }else{
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>" ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;

            }
        }
    }

    html += "";
    document.getElementById("shop_hours").innerHTML = html;
*/
};

</script>

@endsection
@section('footer_js')
@endsection
