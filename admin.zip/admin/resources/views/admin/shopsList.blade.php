@extends('admin.layouts.layout')
@section('content')

<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>ユーザー
    </div>
    <div class="card-body">
        <p>
            <a href="{{ url('shop/create') }}" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>
    <?php foreach($shopList as $shop){ ?>

<div class="card mb-3">
    <div class="card-body">    
        <div class="table-responsive">
            <ul style="list-style: none;">
                    <li>
                        <img>{{$shop['image']}} <br>

                        <h5>{{$shop['name']}}</h5><br>
                        
                        メモ情報{{$shop['description']}} 　<br>

                        予約件数　{{$shop['plan_count']}}<br>

                    <i class="fa fa-phone"></i>
{{$shop['tel']}} 　    <i class="fa fa-envelope"></i>{{$shop['email']}} 　<i class="fa fa-home" aria-hidden="true"></i>{{$shop['address']}} 　 <a href="{{url('shop')}}/{{$shop->id}}">編集 </a><br>
                </li>
            </ul>
        </div>
    </div>
    </div>
    <?php } ?>

</div>
@endsection
@section('footer_js')
@endsection
