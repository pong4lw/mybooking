@extends('admin.layouts.layout')
@section('content')

<style type="text/css">
    .time{
        width:90px;
    }

    .sales{
        width:90px;
    }

    .tax_rate{
        width:90px;
    }

    .price{
        width:120px;
    }
    
</style>
<script src="{{ asset('js/jquery.js') }}"></script>
<link rel="stylesheet" type="text/css" href="{{ asset('js/jquery.timepicker.css') }}" />

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i> <?php $array = explode('-',$date);?>
<?php echo $array[0];?>年

<?php echo $array[1];?>月

<?php echo $array[2];?>日

 営業時間</div>
        <div class="card-body">
            <form action="{{ url('setting/dateedit/') }}/{{$date}}" method="get">
                <div class="form-group">
                    <p>
                        開始時間
                        <input type="text" class="time" id="start" name="start" value="{{$start}}">
                    </p>
                    <p>
                        終了時間
                        <input type="text" class="time" id="end" name="end" value="{{$end}}">
                    </p>

                </div>
                <button type="submit" class="btn btn-success" >更新</button>
            </form>
        </div>
    </div>
    @endsection
    @section('footer_js')
    <script src="{{ asset('js/jquery.culc.js') }}"></script>
    <script src="{{ asset('js/jquery.timepicker.js') }}"></script>

<script>
  $(function() {
    $('.time').timepicker({'timeFormat':'H:i'});
  });
</script>
    @endsection
