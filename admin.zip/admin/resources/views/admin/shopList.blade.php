@extends('admin.layouts.layout')
@section('content')

<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>店舗
    </div>
    <div class="card-body">
        <p>
            <a href="{{ url('shop/new') }}" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>
<?php foreach($shopList as $shop){ ?>

    <div class="card mb-3">
        <div class="card-body">    
            <div class="table-responsive">
                <ul style="list-style: none;">
                    <li>

                        <h5>id:{{$shop['id']}}  <br>{{$shop['name']}}  </h5><br>
                        
                       <!-- 

                    <i class="fa fa-phone"></i>
{{$shop['tel']}} 　    <i class="fa fa-envelope"></i>{{$shop['email']}} 　<i class="fa fa-home" aria-hidden="true"></i>{{$shop['address']}} 　 
-->
<a href="{{url('shop_update')}}/{{$shop->id}}">編集 </a><br>
</li>
</ul>
</div>
</div>
</div>
<?php } ?>

</div>
@endsection
@section('footer_js')
@endsection
