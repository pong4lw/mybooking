@extends('admin.layouts.layout')
@section('content')
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="{{url('/')}}">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">店舗</li>
</ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>店舗
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <form action="{{url('shop_update')}}/{{$shop->id}}" method="post">
                @csrf
                <ul style="list-style: none;">
                    <li>店舗名</li>
                    <li><input id="name" name="name" type="text" value="{{$shop->name}}" style="width:100%"></li>
                </ul>

                <ul style="list-style: none;">
                    <li>店舗URL </li> 
                    <li>
                      <input id="shop_url" name="shop_url" type="text" value="{{$shop->shop_url}}" style="width:100%">
                    </li>
                </ul>

                <ul style="list-style: none;">
                    <li><a href="{{url('shoplist')}}" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
                </ul>

            </form>
        </div>
    </div>
</div>
</div>
@endsection
@section('footer_js')
@endsection
