
<p>登録はこちらから</p>
<p>
    <a href="/company/login">パスワード再設定用URL</a>
</p>
