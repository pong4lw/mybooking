<div>

ご登録ありがとうございます。<br>
ご予約はこちらで承ります。
https://mybooking.jp/sample/public/

</div>