<div>
{{ $usename ?? '' }}	

{{ $text ?? '' }}

{{ $shopname ?? '' }}	
{{ $footer ?? '' }}
</div>