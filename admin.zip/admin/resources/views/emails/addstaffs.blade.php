<div>
{{ $usename ?? '' }}	
{{ $text ?? '' }}
{{ $footer ?? '' }}
</div>