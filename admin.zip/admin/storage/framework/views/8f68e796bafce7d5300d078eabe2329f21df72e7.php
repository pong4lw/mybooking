<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('admin/')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">ユーザー</li>
</ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>ユーザー
    </div>
    <div class="card-body">
 
        <div class="table-responsive">
            <form action="<?php echo e(url('admin/userupdate')); ?>/<?php echo e($user['id']); ?>" method="GET">
            <div><img>画像<?php echo e($user['image']); ?> </div>

            <ul style="list-style: none;">
                <li>氏名</li>
                <li><input id="name" name="name" type="text" value="<?php echo e($user['name']); ?>"></li>
            </ul>

            <ul style="list-style: none;">
                <li><!-- メモ情報<?php echo e($user['description']); ?>--></li>
                <li>電話</li>
                <li><input id="tel" name="tel" type="text" value="<?php echo e($user['tel']); ?>"></li>
            </ul>

            <ul style="list-style: none;"> 
                <li>メール</li>
                <li><input id="email" name="email" type="text" value="<?php echo e($user['email']); ?>"></li> 　
            </ul>

            <ul style="list-style: none;">
                <li>住所</li>
                <li><input id="address" name="address" type="text" value="<?php echo e($user['address']); ?>"></li> 　 
            </ul>

            <ul style="list-style: none;">
                <li><a href="<?php echo e(url('admin/user')); ?>" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
            </ul>

            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin_gym\resources\views/admin/user.blade.php ENDPATH**/ ?>