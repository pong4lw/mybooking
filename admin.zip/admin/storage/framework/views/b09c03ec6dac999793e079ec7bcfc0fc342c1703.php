<?php $__env->startSection('content'); ?>

<style type="text/css">
    .time{
        width:90px;
    }

    .sales{
        width:90px;
    }

    .tax_rate{
        width:90px;
    }

    .price{
        width:120px;
    }
    
</style>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/jquery.timepicker.css')); ?>" />

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i> <?php $array = explode('-',$date);?>
<?php echo $array[0];?>年

<?php echo $array[1];?>月

<?php echo $array[2];?>日

 営業時間</div>
        <div class="card-body">
            <form action="<?php echo e(url('/admin/setting/dateedit/')); ?>/<?php echo e($date); ?>" method="get">
                <div class="form-group">
                    <p>
                        開始時間
                        <input type="text" class="time" id="start" name="start" value="<?php echo e($start); ?>">
                    </p>
                    <p>
                        終了時間
                        <input type="text" class="time" id="end" name="end" value="<?php echo e($end); ?>">
                    </p>

                </div>
                <button type="submit" class="btn btn-success" >更新</button>
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer_js'); ?>
    <script src="<?php echo e(asset('js/jquery.culc.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.timepicker.js')); ?>"></script>

<script>
  $(function() {
    $('.time').timepicker({'timeFormat':'H:i'});
  });
</script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/setting_dateedit.blade.php ENDPATH**/ ?>