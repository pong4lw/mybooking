<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('admin/')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">店舗</li>
</ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>店舗
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <form action="<?php echo e(url('admin/shop_create')); ?>/" method="post">
                <?php echo csrf_field(); ?>
                <ul style="list-style: none;">
                    <li>店舗名</li>
                    <li><input id="name" name="name" type="text" value="" style="width:100%"></li>
                </ul>

                <ul style="list-style: none;">
                    <li>店舗URL </li> 
                    <li>
                      <input id="shop_url" name="shop_url" type="text" value="" style="width:100%">
                    </li>
                </ul>

                <ul style="list-style: none;">
                    <li><a href="<?php echo e(url('admin/shoplist')); ?>" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
                </ul>

            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/shop_create.blade.php ENDPATH**/ ?>