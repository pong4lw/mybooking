<?php $__env->startSection('content'); ?>
<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>スタッフ
    </div>
    <div class="card-body">
        <p>
            <a href="<?php echo e(url('/admin/staff/create')); ?>" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>

<?php foreach($staffs as $staff){ ?>

    <div class="card mb-3">
        <div class="card-body">    
            <div class="table-responsive">
                <ul style="list-style: none;">
                    <li>
<!--
                        <form action= "<?php echo e(url('admin/staff/upload')); ?>/<?php echo e($staff->id); ?>" method ="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            
                            <?php if(session('success')): ?>
                                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>
                            
                             <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <?php if($staff->image): ?>
                                <p>
                                    <img src="<?php echo e(asset('storage/staff/' . $staff->image)); ?>" alt="avatar" />
                                </p>
                                <?php endif; ?>
                                <input type="file" name="file" class = "control-label">
                            </div>

                            <div class="form-group">
                               <input type="submit" class = "btn btn-default">
                           </div>
                       </form>
-->

                       <img><?php echo e($staff['image']); ?> <br>
                       <h5><?php echo e($staff['name']); ?></h5><br>
                       メモ情報<?php echo e($staff['description']); ?> 　<br>
                       予約件数　<?php echo e($staff['plan_count']); ?><br>
                       <i class="fa fa-phone"></i><?php echo e($staff['tel']); ?> 
                       <i class="fa fa-envelope"></i><?php echo e($staff['email']); ?>

                       <i class="fa fa-home" aria-hidden="true"></i><?php echo e($staff['address']); ?> 　 
                       <a href="<?php echo e(url('admin/staff')); ?>/<?php echo e($staff->id); ?>">編集 </a><br>
                   </li>
               </ul>
           </div>
       </div>
   </div>
<?php } ?>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/staffsList.blade.php ENDPATH**/ ?>