<?php $__env->startSection('content'); ?>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>ユーザー
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <form action="<?php echo e(url('userupdate')); ?>/<?php echo e($user['id']); ?>/" method="get">
                <?php echo csrf_field(); ?>
                <!--            <div><img>画像<?php echo e($user['image']); ?> </div>-->

                <ul  class="col-md-6" style="list-style: none;">
                    <li>氏名</li>
                    <li><input class="form-control" id="name" name="name" type="text" value="<?php echo e($user['name']); ?>"></li>
                </ul>

                <ul  class="col-md-6" style="list-style: none;">
                    <li><!-- メモ情報<?php echo e($user['description']); ?>--></li>
                    <li>パスワード</li>
                    <li><input class="form-control" class="form-control" id="password" name="password" type="password" value="<?php echo e($user['password']); ?>"></li>
                </ul>

                <?php if($adminuser->user_type == 'admin'): ?>

                <ul class="col-md-6" style="list-style: none;"> 
                    <li>店舗ID</li>

<!--                    <li><input class="form-control" id="shop_id" name="shop_id" type="text" value="<?php echo e($user['shop_id']); ?>"></li>-->

                    <li>
                      <select id="shop_id" name="shop_id" class="form-control" >
                         <?php foreach($shoplist as $shop){ ?>
                           <option value="<?php echo e($shop->id); ?>" <?php if($user['shop_id'] == $shop->id){ ?> selected="selected" <?php } ?> >ID:<?php echo e($shop->id); ?>  <?php echo e($shop->name ?? ''); ?>  </option>

                        <?php } ?>
                    </select>

                </li>
            </ul>
            <?php endif; ?>

            <ul  class="col-md-6" style="list-style: none;">
                <li><!-- メモ情報<?php echo e($user['description']); ?>--></li>
                <li>電話</li>
                <li><input class="form-control" id="tel" name="tel" type="text" value="<?php echo e($user['tel']); ?>"></li>
            </ul>

            <ul class="col-md-6"  style="list-style: none;"> 
                <li>メール</li>
                <li><input class="form-control" id="email" name="email" type="text" value="<?php echo e($user['email']); ?>"></li> 　
            </ul>

            <ul class="col-md-6"  style="list-style: none;">
                <li>住所</li>
                <li><input class="form-control" id="address" name="address" type="text" value="<?php echo e($user['address']); ?>"></li> 　 
            </ul>

            <ul  class="col-md-6" style="list-style: none;">
                <li><a href="<?php echo e(url('user')); ?>" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
            </ul>

        </form>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\admin\resources\views/admin/user.blade.php ENDPATH**/ ?>