<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('admin/')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">スタッフ</li>
</ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>スタッフ
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <form action="<?php echo e(url('admin/staffupdate')); ?>/<?php echo e($staffs['id']); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <div><img>画像<?php echo e($staffs['image']); ?> </div>
                <!--                    <input type="file" onchange="handleData.previewImage()" class="form-control" id="image" accept="image/*">-->
                <ul style="list-style: none;">
                    <li>氏名</li>
                    <li><input id="name" name="name" type="text" value="<?php echo e($staffs['name']); ?>"></li>
                </ul>

                <ul style="list-style: none;">
                    <li><!-- メモ情報<?php echo e($staffs['description']); ?>--></li>
                    <li>電話</li>
                    <li><input id="tel" name="tel" type="text" value="<?php echo e($staffs['tel']); ?>"></li>
                </ul>

                <ul style="list-style: none;"> 
                    <li>メール</li>
                    <li><input id="email" name="email" type="text" value="<?php echo e($staffs['email']); ?>"></li> 　
                </ul>

                <ul style="list-style: none;">
                    <li>住所</li>
                    <li><input id="address" name="address" type="text" value="<?php echo e($staffs['address']); ?>"></li> 　 
                </ul>

                <ul style="list-style: none;">
                    <li><!-- メモ情報<?php echo e($staffs['description']); ?>--></li>
                    <li>緊急連絡先</li>
                    <li><input id="tel" name="tel2" type="text" value="<?php echo e($staffs['tel2']); ?>"></li>
                </ul>


                <ul style="list-style: none;">
                    <li>スタッフ権限</li>
                    <li>
                    	<select name="user_type">
                    		<option value="staff">STAFF A</option>
                    		<option value="staff2">STAFF B</option>

                    	</select>
                    </li>
                </ul>

<!--
                <ul style="list-style: none;">
                     <li>可能スキル</li>
                    <?php foreach($skill as $k => $v){ ?>
                        <li>
                            <label><input type="checkbox" value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?> <?php echo e($v->used_time); ?></label>
                        </li>
                    <?php } ?>
                </ul>
 -->
                <ul style="list-style: none;">
                    <li><a href="<?php echo e(url('admin/staffs')); ?>" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
                </ul>

            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample\resources\views/admin/staffs.blade.php ENDPATH**/ ?>