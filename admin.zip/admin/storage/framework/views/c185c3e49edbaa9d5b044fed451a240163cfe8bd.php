    <?php $__env->startSection('content'); ?>

<style>
input[type=radio] {
    /*display: none; */
}

input[type="radio"]:checked + label {
    background: #31A9EE;
    color: #ffffff; 
}

.label:hover {
    background-color: #E2EDF9; 
}
    .used_time{
        width:60px;
        text-align: left;
    }

</style>

        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <form action="<?php echo e(url('admin/plan/update')); ?>/" method="get">
            <?php echo csrf_field(); ?>
            <div class="card-header">
                <i class="fa fa-table"></i>予約</div>
                <div class="card-body">
                <div class="form-group" >
                    <label>ユーザー名</label>

                    <p>
                    <select name="user_id" class="form-control col-md-6" >
                        <?php foreach ($users as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                   </select>
                    </p>
                <!--  <input type="" class="form-control" id="user-name">-->
                </div>

                <div class="form-group" class="col-md-6">
                    <label>メニュー</label>
                    <br>

                    <p>
                    <select name="services_id" class="form-control col-md-6" >
                        <?php foreach ($services as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                    </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>スタッフ</label>
                    <br>

                    <p>
                    <select name="staffs_id" class="form-control col-md-3" >
                        <?php foreach ($staffs as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                    </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>予約日時</label>
                     <input name="used_at" id="used_at" class="form-control col-md-3"  type="date" value="<?php echo e(date('Y-m-d')); ?>">
                </div>

                <div class="form-group">
                    <label>予約時間</label>
                    <!--
                    <label><input type="radio" name="timezone">昼の時間帯</label>
                    <label><input type="radio" name="timezone">夕方～夜の時間帯</label>
-->

                <label><input name="open_used_time" id="open_used_time" type="hidden" value=""></label>
                <label><input name="close_used_time" id="close_used_time" type="hidden" value=""></label>

                <div id="shop_hours"></div>
                <br>
                <button type="submit" class="btn btn-success" onclick="saveData()">作成する</button>
            </form>
            </div>
        </div>
<script type="text/javascript">
    document.getElementById("used_at").onchange = function(){ 
        var date = new Date(document.getElementById("used_at").value);
        var day = date.toDateString();

        var week_open_hours = [];
        var week_close_hours = [];

        <?php foreach ($openhours as $i => $week) { ?>

            var opentime_<?php echo $i;?> = '<?php echo $week['open'];?>';

            count = 0;
            if(/pm/.exec(opentime_<?php echo $i;?>) != null){
             count = 12 ; 
             }

         opentime_<?php echo $i;?> = opentime_<?php echo $i;?>.replace('am', '');
         opentime_<?php echo $i;?> = opentime_<?php echo $i;?>.replace('pm', '');

         var date2 = new Date(day + ' ' + opentime_<?php echo $i;?>);

         w = date2.setHours(date2.getHours() + count);

         week_open_hours[<?php echo $i;?>] = date2.toLocaleTimeString();

         var closetime_<?php echo $i;?> = '<?php echo $week['close'];?>';

         count = 0;
         if(/pm/.exec(closetime_<?php echo $i;?>) != null){
             count = 12 ; 
         }

         closetime_<?php echo $i;?> = closetime_<?php echo $i;?>.replace('am', '');
         closetime_<?php echo $i;?> = closetime_<?php echo $i;?>.replace('pm', '');

         var date2 = new Date(day + ' ' + closetime_<?php echo $i;?>);
         w = date2.setHours(date2.getHours() + count);
         week_close_hours[<?php echo $i;?>] = date2.toLocaleTimeString();
     <?php } ?>

     var date2 = new Date(day+' '+ closetime_<?php echo $i;?>);
     w = date2.setHours(date2.getHours() + count);

     document.getElementById("open_used_time").value = week_open_hours[date.getDay()+1];
     document.getElementById("close_used_time").value = week_close_hours[date.getDay()+1];


     var opentimedate = new Date(day+' '+document.getElementById("open_used_time").value);

     var closetimedate = new Date(day+' '+document.getElementById("close_used_time").value);


     var html = "";

     for(var t = 0; t < 24; t++){
        if( t >= opentimedate.getHours() && t <= closetimedate.getHours()){
            if(t == opentimedate.getHours() && opentimedate.getMinutes() != 30) {
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>"  ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>"  ;

            } else if( t == opentimedate.getHours() ){

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;

            }else if(t == closetimedate.getHours() && closetimedate.getMinutes() != 30) {

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>";

            }else if(t == closetimedate.getHours() && closetimedate.getMinutes() == 30) {

                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>" ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;
            }else{
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":00'>" + t +":00</label>" ;
                html += "<label><input class='used_time' name='used_time' type='radio' value='" + t+ ":30'>" + t +":30</label>" ;

            }
        }
    }

    html += "";
    document.getElementById("shop_hours").innerHTML = html;

};

</script>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer_js'); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/plancreate.blade.php ENDPATH**/ ?>