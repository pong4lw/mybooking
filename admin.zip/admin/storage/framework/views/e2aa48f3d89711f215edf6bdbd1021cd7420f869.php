<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(url('admin')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">スタッフ</li>
</ol>
<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>スタッフ
    </div>
    <div class="card-body">
        <p>
            <a href="<?php echo e(url('/admin/staff/create')); ?>" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>

<?php foreach($staffs as $staff){ ?>

    <div class="card mb-3">
        <div class="card-body">    
            <div class="table-responsive">
                <ul style="list-style: none;">
                    <li>
                        <img><?php echo e($staff['image']); ?> <br>
                        <h5><?php echo e($staff['name']); ?></h5><br>
                        メモ情報<?php echo e($staff['description']); ?> 　<br>
                        予約件数　<?php echo e($staff['plan_count']); ?><br>
                        <i class="fa fa-phone"></i><?php echo e($staff['tel']); ?> 
                        <i class="fa fa-envelope"></i><?php echo e($staff['email']); ?>

                        <i class="fa fa-home" aria-hidden="true"></i><?php echo e($staff['address']); ?> 　 
                        <a href="<?php echo e(url('admin/staff')); ?>/<?php echo e($staff->id); ?>">編集 </a><br>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php } ?>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample\resources\views/admin/staffsList.blade.php ENDPATH**/ ?>