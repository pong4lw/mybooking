<?php $__env->startSection('content'); ?>

<style type="text/css">
    .time{
        width:90px;
    }
</style>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/jquery.timepicker.css')); ?>" />

        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(url('admin/setting')); ?>">営業時間</a></li>
            <li class="breadcrumb-item">時間間隔</li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/setting_ticket')); ?>">チケット</a></li>
        </ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i> 時間間隔</div>
        <div class="card-body">
            <form action="<?php echo e(url('/admin/settings_time/update')); ?>" method="get">
                <div class="form-group">
                    <select name ="time">
                    <option value="0">0</option>
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="15">15</option>
                    <option value="20">20</option>
                    <option value="25">25</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success">更新</button>
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer_js'); ?>

    <script src="<?php echo e(asset('js/jquery.timepicker.js')); ?>"></script>
    <script>
        $(function() {
            $('.time').timepicker();
        });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/setting_time.blade.php ENDPATH**/ ?>