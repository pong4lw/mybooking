<?php $__env->startSection('content'); ?>

<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>店舗
    </div>
    <div class="card-body">
        <p>
            <a href="<?php echo e(url('shop/new')); ?>" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>
<?php foreach($shopList as $shop){ ?>

    <div class="card mb-3">
        <div class="card-body">    
            <div class="table-responsive">
                <ul style="list-style: none;">
                    <li>

                        <h5>id:<?php echo e($shop['id']); ?>  <br><?php echo e($shop['name']); ?>  </h5><br>
                        
                       <!-- 

                    <i class="fa fa-phone"></i>
<?php echo e($shop['tel']); ?> 　    <i class="fa fa-envelope"></i><?php echo e($shop['email']); ?> 　<i class="fa fa-home" aria-hidden="true"></i><?php echo e($shop['address']); ?> 　 
-->
<a href="<?php echo e(url('shop_update')); ?>/<?php echo e($shop->id); ?>">編集 </a><br>
</li>
</ul>
</div>
</div>
</div>
<?php } ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\admin\resources\views/admin/shopList.blade.php ENDPATH**/ ?>