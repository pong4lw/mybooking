    <?php $__env->startSection('content'); ?>

<style>
input[type=radio] {
    /*display: none; */
}

input[type="radio"]:checked + label {
    background: #31A9EE;
    color: #ffffff; 
}

.label:hover {
    background-color: #E2EDF9; 
}
</style>

        <ol class="breadcrumb">
            <li class="breadcrumb-item active">ユーザー</li>
            <li class="breadcrumb-item active">メニュー</li>
            <li class="breadcrumb-item active">スタッフ</li>
            <li class="breadcrumb-item active">予約日時</li>
        </ol>

        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <form action="<?php echo e(url('admin/plan/update')); ?>/" method="get">
            <?php echo csrf_field(); ?>
            <div class="card-header">
                <i class="fa fa-table"></i>予約</div>
                <div class="card-body">
                <div class="form-group">
                    <label>ユーザー名</label>

                    <p>
                    <select name="user_id">
                        <?php foreach ($users as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                   </select>
                    </p>
                <!--  <input type="" class="form-control" id="user-name">-->
                </div>

                <div class="form-group">
                    <label>メニュー</label>
                    <br>

                    <p>
                    <select name="services_id">
                        <?php foreach ($services as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                    </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>スタッフ</label>
                    <br>

                    <p>
                    <select name="staffs_id">
                        <?php foreach ($staffs as $k => $v){ ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php } ?>          
                    </select>
                    </p>

                </div>

                <div class="form-group">
                    <label>予約日時</label>
                     <input name="used_at" type="date" value="<?php echo e(date('Y-m-d')); ?>">
                </div>

                <div class="form-group">
                    <label>予約時間</label>
                    <label><input type="radio" name="timezone">昼の時間帯</label>
                    <label><input type="radio" name="timezone">夕方～夜の時間帯</label>
                   <br>
                    昼
                    <label><input name="used_time" type="radio" value="10:00">10:00</label>
                    <label><input name="used_time" type="radio" value="10:30">10:30</label>
                    <label><input name="used_time" type="radio" value="11:00">11:00</label>
                    <label><input name="used_time" type="radio" value="11:30">11:30</label>
                    <label><input name="used_time" type="radio" value="12:00">12:00</label>
                    <label><input name="used_time" type="radio" value="12:30">12:30</label>
                    <label><input name="used_time" type="radio" value="13:00">13:00</label>
                    <label><input name="used_time" type="radio" value="13:30">13:30</label>
                    <label><input name="used_time" type="radio" value="14:00">14:00</label>
                    <label><input name="used_time" type="radio" value="14:30">14:30</label>
                    <label><input name="used_time" type="radio" value="15:00">15:00</label>
                    <label><input name="used_time" type="radio" value="15:30">15:30</label>
                    <br>
                    夕方～夜
                    <input name="used_time" type="radio" value="16:00">16:00
                    <input name="used_time" type="radio" value="16:30">16:30
                    <input name="used_time" type="radio" value="17:00">17:00
                    <input name="used_time" type="radio" value="17:30">17:30
                    <input name="used_time" type="radio" value="18:00">18:00
                    <input name="used_time" type="radio" value="18:30">18:30
                    <input name="used_time" type="radio" value="19:00">19:00
                    <input name="used_time" type="radio" value="19:30">19:30
                    <input name="used_time" type="radio" value="20:00">20:00
                    <input name="used_time" type="radio" value="20:30">20:30
                    <input name="used_time" type="radio" value="21:30">21:00
                    <input name="used_time" type="radio" value="21:30">21:30
                </div>

                <button type="submit" class="btn btn-success" onclick="saveData()">作成する</button>
            </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer_js'); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample\resources\views/admin/plancreate.blade.php ENDPATH**/ ?>