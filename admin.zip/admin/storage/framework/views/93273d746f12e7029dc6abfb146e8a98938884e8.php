<?php $__env->startSection('content'); ?>

<!-- Example DataTables Card-->

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>ユーザー
    </div>
    <div class="card-body">
        <p>
            <a href="<?php echo e(url('user/create')); ?>" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>
    <?php foreach($userList as $user){ ?>

<div class="card mb-3">
    <div class="card-body">    
        <div class="table-responsive">
            <ul style="list-style: none;">
                    <li>
                        <img><?php echo e($user['image']); ?> <br>

                        <h5><?php echo e($user['name']); ?></h5><br>
                        
                        メモ情報<?php echo e($user['description']); ?> 　<br>

                        予約件数　<?php echo e($user['plan_count']); ?><br>

                    <i class="fa fa-phone"></i>
<?php echo e($user['tel']); ?> 　    <i class="fa fa-envelope"></i><?php echo e($user['email']); ?> 　<i class="fa fa-home" aria-hidden="true"></i><?php echo e($user['address']); ?> 　 <a href="<?php echo e(url('user')); ?>/<?php echo e($user->id); ?>">編集 </a><br>
                </li>
            </ul>
        </div>
    </div>
    </div>
    <?php } ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\admin\resources\views/admin/usersList.blade.php ENDPATH**/ ?>