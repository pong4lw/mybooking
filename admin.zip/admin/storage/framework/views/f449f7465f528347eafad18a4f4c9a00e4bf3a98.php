<?php $__env->startSection('content'); ?>

<style>
  .full-height {
    height: 100vh;
  }

  .flex-center {
    align-items: center;
    display: flex;
    justify-content: center;
  }

  .position-ref {
    position: relative;
  }

  .top-right {
    position: absolute;
    right: 10px;
    top: 18px;
  }

  .links > a {
    color: #636b6f;
    padding: 0 25px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: .1rem;
    text-decoration: none;
    text-transform: uppercase;
  }

  .m-b-md {
    margin-bottom: 30px;
  }
  .left { float: left }
  .right { float: right }
  .clear { clear: both }

  #script-warning, #loading { display: none }
  #script-warning { font-weight: bold; color: red }

  #calendar {
    text-align: center; 
    margin: 40px auto;
    padding: 0 10px;
  }

  .tzo {
    color: #000;
  }
  <!--
  #jquery-ui-sortable {
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 70%;
  }
  #jquery-ui-sortable li {
    margin: 0 3px 3px 3px;
    padding: 0.3em;
    padding-left: 1em;
    font-size: 15px;
    font-weight: bold;
    cursor: move;
  }
  -->
</style>

<style type="text/css">
  .time{
    width:90px;
  }
  .fc-title{
    display: none;
  }
</style>

<!-- Example DataTables Card-->
<link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.ui.all.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.4.2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-ui-1.12.1.js' )); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/schedule.css')); ?>" />
<link href="<?php echo e(asset('js/fullcalendar/packages/core/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('js/fullcalendar/packages/daygrid/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('js/fullcalendar/packages/timegrid/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('js/fullcalendar/packages/list/main.css')); ?>" rel='stylesheet' />

<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/moment/main.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jq.schedule.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/core/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/interaction/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/daygrid/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/timegrid/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/fullcalendar/packages/list/main.js')); ?>"></script>

<script type="text/javascript">
  document.addEventListener('DOMContentLoaded', function() {
    var initialTimeZone = 'local';
    var timeZoneSelectorEl = document.getElementById('time-zone-selector');

    var calendarEl = document.getElementById('calendar');
    var todate = new Date(); 
    var todayDate = todate.getFullYear()+'-'+ ("0"+(todate.getMonth() + 1)).slice(-2)+'-'+("0"+todate.getDate()).slice(-2);
    var events = [ ];
    events = 
    [
    <?php foreach($shifts as $k => $v){ ?>
      <?php if($v['used_at']){ ?>
        {title: "<?php echo e($k); ?>", start: "<?php echo e($k); ?>"+"T<?php echo e($v->open ?? '00:00'); ?>", end: "<?php echo e($k); ?>"+"T<?php echo e($v->close ?? '23:59:59'); ?>"},
      <?php } ?>
    <?php } ?>
    ]

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: [ 'interaction', 'dayGrid','list',],
      defaultView: 'dayGridMonth',
      height: 1100,
      locale:'ja',
      timeZone: initialTimeZone,
      header: {
        left: '',
        center: '',
        right: 'listWeek,dayGridMonth',
        resources: []
      },

      views: {
        listMonth: {
          type: 'listWeek',
          duration: { days: 30 },
        }
      },
      eventOverlap:true,
      axisFormat: 'H:mm',
      allDaySlot: false,
      editable: true,
      droppable: true, // will let it receive events!
      defaultDate: todayDate,
      navLinks: true, // can click day/week names to navigate views
      editable: true,
      selectable: true,
      eventLimit: true, // allow "more" link when too many events
      events: events,
      // スクロール開始時間
      firstHour: 6,
      eventTimeFormat: { hour: 'numeric', minute: '2-digit' },

      loading: function(bool) {
      },

      dateClick: function(arg) {
        var date = new Date(arg.date);
        todate = date.getFullYear() + '-' + (parseInt(date.getMonth())+1) + '-' + date.getDate();
        window.location.href = "<?php echo e(url('admin/shift/dateedit')); ?>/"+todate;
      },

      eventClick:function(arg){
        var date = new Date(arg.event['title']);
        todate = date.getFullYear() + '-' + (parseInt(date.getMonth()) + 1) + '-' + date.getDate();
        window.location.href = "<?php echo e(url('admin/shift/dateedit')); ?>/"+todate;
      },

      select: function(arg) {
        console.log('select', calendar.formatIso(arg.start), calendar.formatIso(arg.end));
        var date = new Date(arg.date);
        todate = date.getFullYear() + '-' + (parseInt(date.getMonth())+1) + '-' + date.getDate();
        window.location.href = "<?php echo e(url('admin/shift/dateedit')); ?>/"+todate;
      },

    });
    calendar.render();
  });
</script>

<script>
  document.getElementById('my-prev-button').addEventListener('click', function() {
    calendar.prev();
  });
</script>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/jquery.timepicker.css')); ?>" />

<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> <?php echo date('m');?>月 シフト</div>
    <div class="card-body">
      <form action="<?php echo e(url('/admin/shift/update_week')); ?>" method="get">
        <div class="form-group">
          <table>
            <tr>
              <td>月曜日</td> <td>火曜日</td> <td>水曜日</td><td>木曜日</td> <td>金曜日</td> <td>土曜日</td><td>日曜日</td>
            </tr>
            <tr>
              <td><input name="w1_1" type="text" class="time" value=" <?php if(isset($week[1]['open'])){echo $week[1]['open']; }?>"></td> 
              <td><input name="w2_1" type="text" class="time" value=" <?php echo e($week[2]['open'] ?? ''); ?>"></td> 
              <td><input name="w3_1" type="text" class="time" value=" <?php echo e($week[3]['open'] ?? ''); ?>"></td> 
              <td><input name="w4_1" type="text" class="time" value=" <?php echo e($week[4]['open'] ?? ''); ?>"></td> 
              <td><input name="w5_1" type="text" class="time" value=" <?php echo e($week[5]['open'] ?? ''); ?>"></td> 
              <td><input name="w6_1" type="te" class="time" value=" <?php echo e($week[6]['open'] ?? ''); ?>"></td> 
              <td><input name="w7_1" type="text" class="time" value=" <?php echo e($week[7]['open'] ?? ''); ?>"></td> 
            </tr>

            <tr>
              <td><input name="w1_2" type="text" class="time" value=" <?php echo e($week[1]['close']  ?? ''); ?>"></td>
              <td><input name="w2_2" type="text" class="time" value=" <?php echo e($week[2]['close'] ?? ''); ?>"></td>
              <td><input name="w3_2" type="text" class="time" value=" <?php echo e($week[3]['close']  ?? ''); ?>"></td>
              <td><input name="w4_2" type="text" class="time" value=" <?php echo e($week[4]['close']  ?? ''); ?>"></td>
              <td><input name="w5_2" type="text" class="time" value=" <?php echo e($week[5]['close']  ?? ''); ?>"></td>
              <td><input name="w6_2" type="text" class="time" value=" <?php echo e($week[6]['close']  ?? ''); ?>"></td>
              <td><input name="w7_2" type="text" class="time" value=" <?php echo e($week[7]['close']  ?? ''); ?>"></td>
            </tr>

            <tr>
              <td>
                <select name="spaces_w1">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if($space['id'] == $week[1]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>

              <td>
                <select name="spaces_w2">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[2]['space_id']) && $space['id'] == $week[2]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           
              
              <td>
                <select name="spaces_w3">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[3]['space_id']) && $space['id'] == $week[3]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           
              <td>
                <select name="spaces_w4">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[4]['space_id']) && $space['id'] == $week[4]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           
              <td>
                <select name="spaces_w5">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[5]['space_id']) && $space['id'] == $week[5]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           

              <td>
                <select name="spaces_w6">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[6]['space_id']) && $space['id'] == $week[6]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           
              <td>
                <select name="spaces_w7">
                  <?php foreach ($spaces as $k => $space) { ?>
                    <option value="<?php echo e($space['id'] ?? 1); ?>" <?php if(isset($week[7]['space_id']) && $space['id'] == $week[7]['space_id']){ ?>selected<?php } ?>><?php echo e($space['name']); ?></option>
                  <?php } ?>
                </select>
              </td>           


            </tr>

          </table>

        </div>

        <button type="submit" class="btn btn-success" >更新</button>
      </form>
    </div>
  <div class="card-body">
    <div id="calendar"></div>
  </div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>

<script src="<?php echo e(asset('js/jquery.timepicker.js')); ?>"></script>
<script>
  $(function() {
    $('.time').timepicker({'timeFormat':'H:i'});
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/shift.blade.php ENDPATH**/ ?>