<?php $__env->startSection('content'); ?>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>トレーニング
    </div>
    <div class="card-body">
        <p>
            <a href="<?php echo e(url('admin/services/create')); ?>" class="btn btn-success" role="button">作成する</a>
        </p>
    </div>
</div>
    <?php foreach($services as $service){ ?>
<div class="card mb-3">
    
    <div class="card-body">
        <div class="table-responsive">
            <ul>
                    <li>
                        <?php echo e($service->name); ?>　（<?php echo e($service->used_time); ?>）<br>
                        <?php echo e($service->description); ?> 　<br>
                        <a href="<?php echo e(url('admin/services')); ?>/<?php echo e($service->id); ?>">編集 </a><br>
                </li>
            </ul>
            </div>
        </div>
    </div>

    <?php } ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/admin/serviceslist.blade.php ENDPATH**/ ?>