<div>
スタッフ登録メール
こちらから登録ください
register
</div><?php /**PATH C:\xampp\htdocs\mybooking\sample_admin\resources\views/emails/addstaffs.blade.php ENDPATH**/ ?>