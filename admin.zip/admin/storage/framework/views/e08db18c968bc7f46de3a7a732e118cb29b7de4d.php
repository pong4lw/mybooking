<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="<?php echo e(url('admin/')); ?>">Dashboard</a>
  </li>
  <li class="breadcrumb-item active">通知一覧</li>
</ol>
<div class="card-header">
  <i class="fa fa-table"></i>通知一覧</div>
</div>
<div class="card-body">
  <div class="table-responsive">

  <table>

  <?php foreach($plans as $k => $v){?>
<tr>
<td>
    <?php echo e($v->used_at); ?>

    <?php echo e($v->used_time); ?>

</td>
<td>
    <?php echo e($v->services->name ?? ''); ?>

</td>
<td>
    <?php echo e($v->client->name ?? ''); ?>

</td>
<td>
    <?php echo e($v->provider->name ?? ''); ?>

</td>

</tr>
  <?php } ?>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin_gym\resources\views/admin/notification.blade.php ENDPATH**/ ?>