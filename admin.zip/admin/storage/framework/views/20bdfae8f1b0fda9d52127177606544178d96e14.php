<?php $__env->startSection('content'); ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="<?php echo e(url($shopId.'admin/')); ?>">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">トレーニングメニュー</li>
</ol>

<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i>トレーニングメニュー
    </div>
    <div class="card-body">
 
        <div class="table-responsive">
            <form action="<?php echo e(url($shopId.'admin/services/update')); ?>/<?php echo e($service->id ?? '0'); ?>" method="POST">
<?php echo csrf_field(); ?>
            <ul style="list-style: none;">
                <li>トレーニング名</li>
                <li><input id="name" name="name" type="text" value="<?php echo e($service->name  ?? ''); ?>"></li>
            </ul>

            <ul style="list-style: none;">
                <li>所要時間</li>
                <li>
                    <select id="used_time" name="used_time">
                        <option value="60">60分</option>
                        <option value="90">90分</option>
                        <option value="120">120分</option>
                        <option value="150">150分</option>
                        <option value="180">180分</option>
                        <option value="210">210分</option>
                        <option value="240">240分</option>
                        <option value="270">270分</option>
                    </select>

                </li>
            </ul>

            <ul style="list-style: none;">
                <li>消費チケット</li>
                <li>
                    <select id="tickets" name="tickets">
                        <option value="1">1枚</option>
                        <option value="2">2枚</option>
                        <option value="3">3枚</option>
                        <option value="4">4枚</option>
                        <option value="5">5枚</option>
                    </select>
                </li>
            </ul>

            <ul style="list-style: none;">
                <li><a href="<?php echo e(url($shopId.'/admin/services')); ?>" class="btn" type="button" role="button">戻る</a> <input type="submit" class="btn btn-success" role="button" value="確定"> </li>
            </ul>
            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin_gym\resources\views/admin/services.blade.php ENDPATH**/ ?>