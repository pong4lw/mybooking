<script type="text/javascript">
  document.addEventListener('DOMContentLoaded', function() {

    var initialTimeZone = 'local';
    var timeZoneSelectorEl = document.getElementById('time-zone-selector');

    var calendarEl = document.getElementById('calendar');
    var todate = new Date(); 
    var todayDate = todate.getFullYear()+'-'+ ("0"+(todate.getMonth() + 1)).slice(-2)+'-'+("0"+todate.getDate()).slice(-2);
    var events = [ ];

    events = 
    [
    <?php foreach($plan as $k => $v){ ?>
      <?php if($v['used_at']){ ?>
        {title: "{{$v['used_at'] }}", start: "{{$v['used_at'] }}"+"T"+"09:00", end: "{{$v['used_at'] }}"+"T20:00"},
      <?php } ?>
    <?php } ?>
    ]

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: [ 'interaction', 'dayGrid','list',],
      defaultView: 'dayGridMonth',
      height: 1100,
      timeZone: initialTimeZone,
      header: {
        left: '',
        center: '',
        right: 'listWeek,dayGridMonth',
        resources: []
      },

      views: {
        listMonth: {
          type: 'listWeek',
          duration: { days: 30 },
        }
      },
      eventOverlap:true,
      axisFormat: 'H:mm',
      allDaySlot: false,
      editable: true,
      droppable: true, // will let it receive events!
      defaultDate: todayDate,
      navLinks: true, // can click day/week names to navigate views
      editable: true,
      selectable: true,
      eventLimit: true, // allow "more" link when too many events

//  timeFormat: 'H:mm' ,
events: events,

      // �X�N���[���J�n����
      firstHour: 6,
      eventTimeFormat: { hour: 'numeric', minute: '2-digit' },

      loading: function(bool) {
      },

      dateClick: function(arg) {

        console.log('dateClick', calendar.formatIso(arg.date));

      var date = new Date(arg.date);
      console.log(date);
      console.log(date.getFullYear());
      console.log(date.getMonth());
      console.log(date.getDate());

      todate = date.getFullYear() + '-' + (date.getMonth()+1) + '-' + date.getDate();
      window.location.href = "{{ url('admin/setting/dateedit') }}/"+todate;

/*
        var event = calendar.getEventSources();
        calendar.addEventSource([{
          id:event.length
          ,title:' '
          ,start:arg.date
          ,end:arg.date
        }]);
        calendar.refetchEvents();
  */},
  eventClick:function(arg){
      var date = new Date(arg.event['title']);
      todate = date.getFullYear() + '-' + date.getMonth() + 1 + '-' + date.getDate();
      window.location.href = "{{ url('admin/setting/dateedit') }}/"+todate;
  },
      select: function(arg) {
        console.log('select', calendar.formatIso(arg.start), calendar.formatIso(arg.end));
      var date = new Date(arg.date);
      todate = date.getFullYear() + '-' + date.getMonth() + '-' + date.getDate();
      window.location.href = "{{ url('admin/setting/dateedit') }}/"+todate;

      },

    });


  calendar.render();
});

</script>
