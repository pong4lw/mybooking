<?php

Route::get('admin/login','Admin\Auth\LoginController@showLoginForm')->name('login');
Route::post('admin/login','Admin\Auth\LoginController@login');

Route::get('/login','Admin\Auth\LoginController@showLoginForm');
Route::post('/login','Admin\Auth\LoginController@login')->name('login');

Route::get('/reset','Admin\Auth\ResetPasswordController@showLinkRequestForm')->name('password.request');
Route::post('/update','Admin\Auth\ResetPasswordController@update')->name('password.update');
Route::post('password/email', 'Admin\Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');

Route::get('/logout','Admin\Auth\LoginController@logout')->name('logout');
Route::post('/logout','Admin\Auth\LoginController@logout')->name('logout');


//Auth::route();

//admins
Route::group(['middleware' => 'auth:admin'],function(){
	Route::get('/home','AdminController@index');

	Route::get('logout','Admin\Auth\LoginController@logout');
	Route::post('logout','Admin\Auth\LoginController@logout')->name('logout');

	Route::get('/', 'AdminController@index');
	Route::post('/', 'AdminController@index');
	Route::get('/index', 'AdminController@index');
	Route::post('/index', 'AdminController@index');

	Route::get('/shop/create','Admin\ShopController@create');
	Route::post('/shop/create','Admin\ShopController@create');

	Route::get('/shop/new/','Admin\ShopController@new');

	Route::get('/shop_update/{shop_id}','Admin\ShopController@edit');
	Route::post('/shop_update/{shop_id}','Admin\ShopController@update');

	Route::get('/shop_update','Admin\ShopController@create');
	Route::post('/shop_update','Admin\ShopController@create');

	Route::get('/shop_create','Admin\ShopController@create');
	Route::post('/shop_create','Admin\ShopController@create');

	Route::get('/shoplist', 'Admin\ShopController@shoplist');
	Route::post('/shoplist', 'Admin\ShopController@shoplist');
	
	Route::post('/shop/{shop_id}', 'Admin\ShopController@shop');

	Route::get('/user', 'Admin\UserController@userlist');

	Route::get('/user/{id}', 'Admin\UserController@user');
	Route::post('/user/{id}', 'Admin\UserController@user');

	Route::get('/userupdate/{id}', 'Admin\UserController@userupdate');
	Route::post('/userupdate/{id}', 'Admin\UserController@userupdate');

	Route::get('/userupdate/', 'Admin\UserController@userupdate');
	Route::post('/userupdate/', 'Admin\StaffController@userupdate');

	Route::get('/staff', 'Admin\StaffController@stafflist');
	Route::get('/staffs', 'Admin\StaffController@stafflist');
	Route::post('/staffs', 'Admin\StaffController@stafflist');

	Route::get('/staff/upload/{id}', 'Admin\StaffController@upload');
	Route::post('/staff/upload/{id}', 'Admin\StaffController@upload');

	Route::post('/staff/addmail', 'Admin\StaffController@staffaddmail');

	Route::get('/staff/add', 'Admin\StaffController@staffadd');

	Route::get('/staff/{id}', 'Admin\StaffController@staff');
	Route::post('/staff/{id}', 'Admin\StaffController@staff');

	Route::get('/staffupdate/', 'Admin\StaffController@staffupdate');
	Route::post('/staffupdate/', 'Admin\StaffController@staffupdate');

	Route::get('/staffupdate/{id}', 'Admin\StaffController@staffupdate');
	Route::post('/staffupdate/{id}', 'Admin\StaffController@staffupdate');

	Route::get('/schedule', 'Admin\PlanController@schedule');
	Route::post('/schedule', 'Admin\PlanController@schedule');

	Route::get('/services', 'Admin\ServiceController@index');
	Route::post('/services', 'Admin\ServiceController@index');

	Route::get('/services/{id}/', 'Admin\ServiceController@service');
	Route::post('/services/{id}/', 'Admin\ServiceController@service');

	Route::get('/services/create', 'Admin\ServiceController@create');
	Route::post('/services/create', 'Admin\ServiceController@create');

	Route::get('/services/update/{id?}/', 'Admin\ServiceController@update');
	Route::post('/services/update/{id?}/', 'Admin\ServiceController@update');

	Route::get('/plan/create', 'Admin\PlanController@create');
	Route::get('/plan/edit/{id?}', 'Admin\PlanController@edit');

	Route::get('/plan/update/{id?}/', 'Admin\PlanController@update');
	Route::post('/plan/update/{id?}/', 'Admin\PlanController@update');

	Route::get('/shift/', 'Admin\ShiftController@index');
	Route::post('/shift/', 'Admin\ShiftController@index');

	Route::get('/shift/create/', 'Admin\ShiftController@create');
	Route::post('/shift/create/', 'Admin\ShiftController@create');

	Route::get('/shift/dateedit/{date}', 'Admin\ShiftController@dateedit');
	Route::post('/shift/dateedit/{date}', 'Admin\ShiftController@dateedit');

	Route::get('/shift/update/{id}', 'Admin\ShiftController@update');
	Route::post('/shift/update/{id}', 'Admin\ShiftController@update');

	Route::get('/reservation', 'AdminController@reservation');

	Route::get('/','AdminController@index');

	Route::get('/notification','AdminController@notification');

	Route::get('/help', 'Admin\SettingController@index');
	Route::post('/help', 'Admin\SettingController@index');

	Route::get('/setting', 'Admin\SettingController@index');
	Route::post('/setting', 'Admin\SettingController@index');	

	Route::get('/setting/dateedit/{date}/', 'Admin\SettingController@dateedit');
	Route::post('/setting/dateedit/{date}/', 'Admin\SettingController@dateedit');

	Route::get('/setting/update', 'Admin\SettingController@update');
	Route::post('/setting/update', 'Admin\SettingController@update');

	Route::get('/setting_time', 'Admin\SettingController@time');
	Route::post('/setting_time', 'Admin\SettingController@time');

	Route::get('/settings_time/update', 'Admin\SettingController@timeupdate');

	Route::post('/settings_time/update', 'Admin\SettingController@timeupdate');

	Route::get('/shift/update_week', 'Admin\ShiftController@update_week');
	Route::post('/shift/update_week', 'Admin\ShiftController@update_week');

	Route::get('/shift/dateedit/{date}/', 'Admin\ShiftController@dateedit');
	Route::post('/shift/dateedit/{date}/', 'Admin\ShiftController@dateedit');

	Route::get('/shift/test', 'Admin\ShiftController@test');

	Route::post('/plan/searchScheduleByStaffJson', 'planController@searchScheduleByStaffJson');

	Route::get('/plan/searchScheduleByStaffJson', 'Admin\planController@searchScheduleByStaffJson');

	Route::get('/plan/scheduleByDayJson/{staffId}/{day}/', 'Admin\planController@scheduleByDayJson');
	Route::post('/plan/scheduleByDayJson/{staffId}/{day}/', 'Admin\planController@scheduleByDayJson');

	Route::get('/mail/test', 'Admin\userController@mail');
});
Route::group(['prefix' => 'admin','middleware' => 'auth:admin'],function(){
	Route::get('/home','AdminController@index');

	Route::get('logout','Admin\Auth\LoginController@logout');
	Route::post('logout','Admin\Auth\LoginController@logout')->name('logout');

	Route::get('/', 'AdminController@index');
	Route::post('/', 'AdminController@index');
	Route::get('/index', 'AdminController@index');
	Route::post('/index', 'AdminController@index');

	Route::get('/shop/create','Admin\ShopController@create');
	Route::post('/shop/create','Admin\ShopController@create');

	Route::get('/shop/new/','Admin\ShopController@new');

	Route::get('/shop_update/{shop_id}','Admin\ShopController@edit');
	Route::post('/shop_update/{shop_id}','Admin\ShopController@update');

	Route::get('/shop_update','Admin\ShopController@create');
	Route::post('/shop_update','Admin\ShopController@create');

	Route::get('/shop_create','Admin\ShopController@create');
	Route::post('/shop_create','Admin\ShopController@create');

	Route::get('/shoplist', 'Admin\ShopController@shoplist');
	Route::post('/shoplist', 'Admin\ShopController@shoplist');
	
	Route::post('/shop/{shop_id}', 'Admin\ShopController@shop');

	Route::get('/user', 'Admin\UserController@userlist');

	Route::get('/user/{id}', 'Admin\UserController@user');
	Route::post('/user/{id}', 'Admin\UserController@user');

	Route::get('/userupdate/{id}', 'Admin\UserController@userupdate');
	Route::post('/userupdate/{id}', 'Admin\UserController@userupdate');

	Route::get('/userupdate/', 'Admin\UserController@userupdate');
	Route::post('/userupdate/', 'Admin\StaffController@userupdate');

	Route::get('/staff', 'Admin\StaffController@stafflist');
	Route::get('/staffs', 'Admin\StaffController@stafflist');
	Route::post('/staffs', 'Admin\StaffController@stafflist');

	Route::get('/staff/upload/{id}', 'Admin\StaffController@upload');
	Route::post('/staff/upload/{id}', 'Admin\StaffController@upload');

	Route::post('/staff/addmail', 'Admin\StaffController@staffaddmail');

	Route::get('/staff/add', 'Admin\StaffController@staffadd');

	Route::get('/staff/{id}', 'Admin\StaffController@staff');
	Route::post('/staff/{id}', 'Admin\StaffController@staff');

	Route::get('/staffupdate/', 'Admin\StaffController@staffupdate');
	Route::post('/staffupdate/', 'Admin\StaffController@staffupdate');

	Route::get('/staffupdate/{id}', 'Admin\StaffController@staffupdate');
	Route::post('/staffupdate/{id}', 'Admin\StaffController@staffupdate');

	Route::get('/schedule', 'Admin\PlanController@schedule');
	Route::post('/schedule', 'Admin\PlanController@schedule');

	Route::get('/services', 'Admin\ServiceController@index');
	Route::post('/services', 'Admin\ServiceController@index');

	Route::get('/services/{id}/', 'Admin\ServiceController@service');
	Route::post('/services/{id}/', 'Admin\ServiceController@service');

	Route::get('/services/create', 'Admin\ServiceController@create');
	Route::post('/services/create', 'Admin\ServiceController@create');

	Route::get('/services/update/{id?}/', 'Admin\ServiceController@update');
	Route::post('/services/update/{id?}/', 'Admin\ServiceController@update');

	Route::get('/plan/create', 'Admin\PlanController@create');
	Route::get('/plan/edit/{id?}', 'Admin\PlanController@edit');

	Route::get('/plan/update/{id?}/', 'Admin\PlanController@update');
	Route::post('/plan/update/{id?}/', 'Admin\PlanController@update');

	Route::get('/shift/', 'Admin\ShiftController@index');
	Route::post('/shift/', 'Admin\ShiftController@index');

	Route::get('/shift/create/', 'Admin\ShiftController@create');
	Route::post('/shift/create/', 'Admin\ShiftController@create');

	Route::get('/shift/dateedit/{date}', 'Admin\ShiftController@dateedit');
	Route::post('/shift/dateedit/{date}', 'Admin\ShiftController@dateedit');

	Route::get('/shift/update/{id}', 'Admin\ShiftController@update');
	Route::post('/shift/update/{id}', 'Admin\ShiftController@update');

	Route::get('/reservation', 'AdminController@reservation');

	Route::get('/','AdminController@index');

	Route::get('/notification','AdminController@notification');

	Route::get('/help', 'Admin\SettingController@index');
	Route::post('/help', 'Admin\SettingController@index');

	Route::get('/setting', 'Admin\SettingController@index');
	Route::post('/setting', 'Admin\SettingController@index');	

	Route::get('/setting/dateedit/{date}/', 'Admin\SettingController@dateedit');
	Route::post('/setting/dateedit/{date}/', 'Admin\SettingController@dateedit');

	Route::get('/setting/update', 'Admin\SettingController@update');
	Route::post('/setting/update', 'Admin\SettingController@update');

	Route::get('/setting_time', 'Admin\SettingController@time');
	Route::post('/setting_time', 'Admin\SettingController@time');

	Route::get('/settings_time/update', 'Admin\SettingController@timeupdate');

	Route::post('/settings_time/update', 'Admin\SettingController@timeupdate');

	Route::get('/shift/update_week', 'Admin\ShiftController@update_week');
	Route::post('/shift/update_week', 'Admin\ShiftController@update_week');

	Route::get('/shift/dateedit/{date}/', 'Admin\ShiftController@dateedit');
	Route::post('/shift/dateedit/{date}/', 'Admin\ShiftController@dateedit');

	Route::get('/shift/test', 'Admin\ShiftController@test');

	Route::post('/plan/searchScheduleByStaffJson', 'planController@searchScheduleByStaffJson');

	Route::get('/plan/searchScheduleByStaffJson', 'Admin\planController@searchScheduleByStaffJson');

	Route::get('/plan/scheduleByDayJson/{staffId}/{day}/', 'Admin\planController@scheduleByDayJson');
	Route::post('/plan/scheduleByDayJson/{staffId}/{day}/', 'Admin\planController@scheduleByDayJson');

	Route::get('/mail/test', 'Admin\userController@mail');
});


