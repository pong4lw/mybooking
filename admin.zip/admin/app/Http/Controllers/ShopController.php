<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Models\Shops;
use App\Models\Shopdsp;


class ShopController extends Controller
{
    public function index()
    {
    	$shops = new Shops();
    	echo "<pre>";
    	print_r($shops->shopIdArray);
    	echo "</pre>";

//        return view('shop');
    }
}