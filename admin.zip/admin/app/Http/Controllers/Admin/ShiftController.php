<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Auth;

use App\Models\Services;
use App\Models\Service_descriptions;
use App\Models\Provieder_appoints;
use App\Models\Provieder_services;
use App\Models\Users;
use App\Models\Shops;
use App\Models\Tickets;
use App\Models\Admins;
use App\Models\provider_appoints;
use App\Models\Shop_tickets;
use App\Models\Settings_time;
use App\Models\Settings_bussiness_time;
use App\Models\Spaces;
use App\Models\Shift;
use App\Models\Shift_week;
use App\Models\Shift_day;

use Carbon\Carbon;

class ShiftController extends Controller
{
	public function __construct()
	{
//		$this->middleware('auth');
	}

	public function index(){
		$shops = new Shops();
		$id = Auth::id() ?? 1;
		$list['services'] = Services::all();

		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);
		$settingTime = Settings_time::where('shop_id',Shops::$shopId)->first();

		$list['shifts'] = Shift::searchShift($id);
		$list['week'] = Shift_week::weekArray('shop_id', Shops::$shopId);
		if(!isset($list['week'][1]))$list['week'][1]=array('space_id' =>1);
		if(!isset($list['week'][2]))$list['week'][2]=array('space_id' =>1);
		if(!isset($list['week'][3]))$list['week'][3]=array('space_id' =>1);
		if(!isset($list['week'][4]))$list['week'][4]=array('space_id' =>1);
		if(!isset($list['week'][5]))$list['week'][5]=array('space_id' =>1);
		if(!isset($list['week'][6]))$list['week'][6]=array('space_id' =>1);
		if(!isset($list['week'][7]))$list['week'][7]=array('space_id' =>1);
		
		$list['spaces'] = Spaces::where('shop_id', Shops::$shopId)->get();
		$admins = Admins::where('shop_id', Shops::$shopId)->get();

		return view('admin.shift', $list);
	}

	public function searchScheduleByStaffJson(){
		$shop_id = Shops::$shopId;
		if(empty($_REQUEST['staff_id'])){
			return json_encode(array());
		}
		$staff_id = $_REQUEST['staff_id'];
		$result = provider_appoints::where('provider_id', $staff_id)->where('shop_id', $shop_id)->get();
		return json_encode($result);
	}

	public function scheduleByDayJson($staffId = null,$day = null){
		$shop_id = Shops::$shopId;
		if(empty($day)){
			return json_encode(array());
		}
		$settings_bussiness_time = Settings_bussiness_time::where('used_at', $day)->first();
		$result = provider_appoints::where('shop_id', $shop_id)->where('provider_id',$staffId)->where('used_at', $day)->where('is_delete', 0)->get();
		
		$week = date('w',strtotime($day));
		if(!isset($settings_bussiness_time['start']) && is_null($settings_bussiness_time['start'])){
			$result['settings_start'] = Shops::where('shop_id', $shop_id)->where('week', $week)->first()->open;
		}else{
			$result['settings_start'] = $settings_bussiness_time['start'];
		}

		if(!isset($settings_bussiness_time['end']) && is_null($settings_bussiness_time['end'])){
			$result['settings_end'] = Shops::where('shop_id', $shop_id)->where('week', $week)->first()->close;
		}else{
			$result['settings_end'] = $settings_bussiness_time['end'];
		}

		$result['settings_time'] = Settings_time::where('shop_id', $shop_id)->first()->value;
		return json_encode($result);
	}

	public function dateedit($date = ''){
		$list = array();
		$id = 1;
		$list['date'] = $date;
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		$Shift_day = Shift_day::where('shop_id', Shops::$shopId)->where('used_at',$date)->where('provider_id',$id)->first();
		$week = date('w',strtotime($date));
		if($week == 0){
			$week = 	7;
		}

		if(isset($_REQUEST['start']) || isset($_REQUEST['end'])){
			$list['start'] = $_REQUEST['start'] ?? '';
			$list['end'] = $_REQUEST['end'] ?? '';

		}elseif(is_null($Shift_day)){
			$list['start'] = Shift_week::where('shop_id', Shops::$shopId)->where('week', $week)->first()->open ?? '';
			$list['end'] = Shift_week::where('shop_id', Shops::$shopId)->where('week', $week)->first()->close ?? '';
		}elseif(!is_null($Shift_day)){
			$list['start'] = $Shift_day['open'] ?? '';
			$list['end'] = $Shift_day['close'] ?? '';

		}
		if(is_null($Shift_day)){
			$Shift_day = new Shift_day();
		}

		if(isset($_REQUEST['start']) || isset($_REQUEST['end'])){
			$Shift_day['name'] = $date;
			$Shift_day['used_at'] = $date;
			$Shift_day['provider_id'] = $id;
			$Shift_day['shop_id'] = Shops::$shopId;
			$Shift_day['open'] = $_REQUEST['start'];
			$Shift_day['close'] = $_REQUEST['end'];
			$Shift_day->save();
			return $this->index();
		}
		$list['spaces'] = Spaces::where('shop_id', Shops::$shopId)->get();

		return view('admin.shift_edit', $list);
	}

	public function create(){
		$shops = new Shops();
		$list['openhours'] = $shops->open_hours_week();

		$list['services'] = Services::where('shop_id', Shops::$shopId)->get();
		$list['users'] = Users::where('shop_id', Shops::$shopId)->get();
		$list['staffs'] = Admins::where('shop_id', Shops::$shopId)->get();
		return view('admin.shiftcreate', $list);
	}

	public function update($id = null){
		$shops = new Shops();
		$list['provider_appoints'] = Shift::find($id);
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		if($list['provider_appoints'] == null){
			$list['provider_appoints'] = new provider_appoints();
		}
		$list['provider_appoints']->name = Shops::$shopId.'-'.$_REQUEST['services_id'].$_REQUEST['staffs_id'].$_REQUEST['user_id'].$_REQUEST['used_at'];
		$list['provider_appoints']->space_id = '1';
		$list['provider_appoints']->client_id = $_REQUEST['user_id'];
		$list['provider_appoints']->services_id = $_REQUEST['services_id'];
		$list['provider_appoints']->provider_id = $_REQUEST['staffs_id'];
		$list['provider_appoints']->shop_id = Shops::$shopId;
		$list['provider_appoints']->used_at = $_REQUEST['used_at'];
		$list['provider_appoints']->used_time = str_pad($_REQUEST['used_time'],5,0,STR_PAD_LEFT) ?? '10:00';
		$list['provider_appoints']->save();
		return redirect('admin/schedule');
//		return $this->index();
	}

	public function edit($id = null){
		$shops = new Shops();
		$list['openhours'] = $shops->open_hours_week();

		if(is_null($id)){
			return $this->create();
		}

		$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		$list['services'] = Services::where('shop_id', Shops::$shopId)->get();
		$list['users'] = Users::where('shop_id', Shops::$shopId)->get();
		$list['staffs'] = Admins::where('shop_id', Shops::$shopId)->get();
		$list['plan'] = provider_appoints::find($id);

		return view('admin.shiftedit', $list);
	}

	public function schedule(){
		$plan = new provider_appoints();
		$list['settings_time'] = Settings_time::where('shop_id','=',Shops::$shopId)->first()->value;
		$list['plan'] = $plan->find_all();
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		
		$list['staffs'] = array();

		$admins = Admins::where('shop_id',Shops::$shopId)->get();
		foreach ($admins as $k => $v) {
			$list['staffs'][$v['id']] = $v['name'];
		}

		return view('admin.shift', $list);
	}

	public function update_week(){
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		$id = Auth::id() ?? 1;
		$shiftWeeek = Shift_week::where('shop_id', '=', Shops::$shopId)->where('provider_id','=',$id)->first();
		$list['staffs'] = array();

		for($i =1 ; $i <=7 ; $i++){
			$array['open'] = $_REQUEST['w'.$i.'_1'];
			$array['close'] = $_REQUEST['w'.$i.'_2'];
			$array['space_id'] = $_REQUEST['spaces_w'.$i];
			$array['provider_id'] = $id;
			$array['week'] = $i;
			$array['shop_id'] = Shops::$shopId;
			Shift_week::update_week($array);
		}
		return $this->index();
	}	

	public function test(){
		$id =1;
		$shops = new Shops();
		$list['services'] = Services::all();
		$list['adminuser'] = Admins::find($id);
		$settingTime = Settings_time::where('shop_id',Shops::$shopId)->first();
		$list['plan'] = provider_appoints::all();

		foreach($list['plan'] as $k => $plan) {
			$staff = Admins::where('id', '=', $plan['provider_id'])->first();
			$services = Services::where('id', '=', $plan['services_id'])->first();
			$list['plan'][$k]['services'] = $services->name ?? '';
			$list['plan'][$k]['provider'] = $staff->name ?? '';
			$list['plan'][$k]['client'] = Users::where('id', '=', $plan['client_id'])->first()->name ?? '';
			$list['plan'][$k]['services_time'] = $services->used_time ?? '';
			$list['plan'][$k]['ticket'] = $services->value ?? '';
			$time = new Carbon($plan->used_time);
			$list['plan'][$k]['end_time'] = $time->addSecond($services->used_time * 60);
		}

		$admins = Admins::where('shop_id', Shops::$shopId)->get();
		foreach ($admins as $k => $v) {
			$list['staffs'][$v['id']] = $v['name'];
		}

		$shift = Shift::searchShift($id);
		
		
		return view('admin.shift', $list);
	}

/*
	public function reservation(){
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		$list['services'] = Services::type();
		$list['staffs'] = array('StaffA','StaffB','Admin');
		return view('admin.reservation',$list);
	}
*/
/*
	public function reservation_conform(){
		$clientId = '';
		$list['services'] = Services::type();
		$list['services'] = array($_REQUEST["services"] => $list['services'][$_REQUEST["services"]]);

		$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		$list['staffs'] = Admins::where('shop_id', Shops::$shopId)->get();
		$list['staffs'] = array($_REQUEST["staffs"] => $list['staffs'][$_REQUEST["staffs"]]);
		$list['re_date'] = $_REQUEST["re_date"];

		$list['tickets'] = Tickets::where('client_id', Auth::user()->id)->get();
		$list['tickets'] = $list['tickets'][0]->count;

		return view('user.reservation_conform', $list);
	}

	public function reservation_comp(){
		$shops = new Shops();
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		$clientId = '';
		$list['services'] = Services::type();
		$list['services'] = array($_REQUEST["services"] => $list['services'][$_REQUEST["services"]]);
		$list['staffs'] = Admins::where('shop_id', Shops::$shopId)->get();
		$list['staffs'] = array($_REQUEST["staffs"] => $list['staffs'][$_REQUEST["staffs"]]);
		$list['re_date'] = $_REQUEST["re_date"];

		$Tickets = Tickets::where('client_id', Auth::user()->id)->get();
		$Tickets = $Tickets[0];

		$count = $Tickets->count;

		$list['Tickets'] = $count;
		if($count == 0){
			return view('user.reservation_conform', $list);
		}

		$provider_appoints = new provider_appoints();

		$list['provider_appoints']->name = Shops::$shopId.'-'.$_REQUEST['services'].$_REQUEST['staffs'].$_REQUEST['user_id'].$_REQUEST['re_date'];

		$provider_appoints->client_id = Auth::user()->id;
		$provider_appoints->space_id = 1;
		$provider_appoints->services_id = $_REQUEST['services'];
		$provider_appoints->provider_id = $_REQUEST['staffs'];
		$provider_appoints->used_at = $_REQUEST['re_date'];
		$provider_appoints->shop_id = Shops::$shopId;
		$provider_appoints->save();

		$db = Tickets::where('client_id',Auth::user()->id)->update(['count' => $count-1]);

		$list['tickets'] = $count-1;

		return view('user.reservation_comp', $list);
	}

	public function ticketadd(){
		$shops = new Shops();
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		$db = Tickets::where('client_id',Auth::user()->id)->update(['count' => 2]);

		if(!$db){
			$db = new Tickets();
			$db->client_id = Auth::user()->id;
			$db->count = 1;
			$db->shop_id = Shops::$shopId;
			$db->save();
		}
	}

	public function ticketuse(){
		$shops = new Shops();
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		$Tickets = Tickets::where('client_id', Auth::user()->id)->get();
		$Tickets = $Tickets[0];

		$count = $Tickets->count;

		if($count == 0){
			return false;
		}

		$db = Tickets::where('client_id',Auth::user()->id)->update(['count' => $count-1]);

		if(!$db){
			return false;
		}
	}
*/
}
