<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\RegisterMail;
use App\Models\Shops;

class MailController extends Controller
{
  static public function staffregister(){
    $email = $_REQUEST['email'];
    $name =""
    $name = '';
    $text = '登録しました。';
    $to = 'hiroki.hon@gmail.com';

    Mail::to($to)->send(new RegisterMail($name, $text));
  }

  static public function userregister($name,$email,$password){
  	$shopName = Shops::$shopArray[Shops::$shopId];
    $text = $name '様 \n\r '.$shopName.'店に登録しました。\r\n パスワード'.$password;
    $to = $email;
    Mail::to($to)->send(new RegisterMail($name, $text));
  }


  static public function staffmessage(){

    $name = '';
    $text = '登録しました。';
    $to = 'hiroki.hon@gmail.com';

    Mail::to($to)->send(new RegisterMail($name, $text));
  }

  static public function usermessage(){
    $text = $_REQUEST['text'];
    $to = $_REQUEST['email'];

    $name = '';

    Mail::to($to)->send(new RegisterMail($name, $text));
  }


}
