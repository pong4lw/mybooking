<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\Models\Service;
use App\Models\Service_descriptions;
use App\Models\Spaces;
use App\Models\Provieder_appoints;
use App\Models\Provieder_services;
use App\Models\Users;
use App\Models\Admins;
use App\Models\Tickets;
use App\Models\Plans;
use App\Models\Shops;
use App\Models\Shop_tickets;
use App\Models\Settings_time;
use App\Models\Settings_bussiness_time;

class SettingController extends Controller
{
	public function __construct()
	{
	//		$this->middleware('auth');
	}

	public function index(){
		$shops = new Shops();
		$id = 1;
		$list['week'] = array();

		for( $w = 1; $w <= 7 ; $w++ ){
			$shops = Shops::where('week', '=', $w)->where('shop_id', Shops::$shopId)->first();
			if(is_null($shops)){
				$shops = new Shops();
			}
			$list['week'][$w]['start'] = $shops->open ?? "";
			$list['week'][$w]['end'] = $shops->close ?? "";
		}
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		$list['restPlans'] = Settings_bussiness_time::searchBussinessTime($id);
/*
		$setting = settings_bussiness_time::where('shop_id', Shops::$shopId)->where('used_at','>=',date('Y-m-1'))->where('used_at','<=',date('Y-m-31'))->get();;
		$list['restPlans'] = $setting;
*/
		return view('admin.setting', $list);
	}

	public function ticket(){
		$shops = new Shops();
		$list['tickets'] = Shop_Tickets::where('shop_id', Shops::$shopId)->get();
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		return view('admin.setting_ticket', $list);	
	}

	public function time(){
		$shops = new Shops();
		$list['time'] = Settings_time::where('shop_id', Shops::$shopId)->first();
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		return view('admin.setting_time', $list);
	}

	public function timeupdate(){
		$shops = new Shops();
		$list['time'] = $_REQUEST['time'];

		$list['time'] = Settings_time::where('shop_id', Shops::$shopId)->first();
		if(is_null($list['time'])){
			$list['time'] = new Settings_time();
		}
		$list['time']->value = $_REQUEST['time'];
		$list['time']->shop_id = Shops::$shopId;
		$list['time']->save();

		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		return view('admin.setting_time',$list);
	}

	public function ticket_update(){
		$shops = new Shops();
		$list['tickets'] = Shop_Tickets::where('shop_id', Shops::$shopId)->get();
		foreach ($_GET['sales'] as $k => $v) {
			$array[$k]['sales'] = (int)$v ?? 0;
		}
		foreach ($_GET['unit_price'] as $k => $v) {
			$array[$k]['unit_price'] = (int)$v ?? 0;
		}
		foreach ($_GET['tax_rate'] as $k => $v) {
			$array[$k]['tax_rate'] = (int)$v ?? 0;
		}
		foreach ($array as $k => $v) {
			$Shop_Tickets = Shop_Tickets::find($k);
			if(is_null($Shop_Tickets)){
				$Shop_Tickets = new Shop_Tickets();
			}
			$price = $v['sales'] * $v['unit_price'] + $v['sales'] * $v['unit_price'] * $v['tax_rate']/100 ;
			$Shop_Tickets->sales = $v['sales'] ?? 0;
			$Shop_Tickets->unit_price = $v['unit_price'] ?? 0;
			$Shop_Tickets->tax_rate = $v['tax_rate'] ?? 0;
			$Shop_Tickets->price = (int)$price;

			$Shop_Tickets->save();
		}
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		return redirect('admin/setting_ticket');
	}

	public function ticket_delete(){
		$shops = new Shops();
		$Shop_Tickets = Shop_Tickets::where('shop_id', Shops::$shopId)->where('id', $_GET['id'])->get();
		if(!is_null($Shop_Tickets)){$Shop_Tickets->delete();}
		return $this->ticket();
	}

	public function dateedit($date = ''){
		$list = array();
		$list['date'] = $date;
		$setting = Settings_bussiness_time::where('shop_id',Shops::$shopId)->where('used_at',$date)->first();
		$week = date('w', strtotime($date));
		if($week == 0 ){
			$week = 7;
		}
		if($setting == null){
			$shops = Shops::where('week',$week)->where('shop_id',Shops::$shopId)->first();
			$list['start'] = $shops->open ?? '0:00';
			$list['end'] = $shops->close ?? '23:00';
		}else{
			$list['start'] = $setting['start'];
			$list['end'] = $setting['end'];
		}

		if(isset($_REQUEST['start']) || isset($_REQUEST['end'])){
			$setting['name'] = $date;
			$setting['used_at'] = $date;
			$setting['start'] = $_REQUEST['start'];
			$setting['end'] = $_REQUEST['end'];
			$setting->save();
			return $this->index();
		}
		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		return view('admin.setting_dateedit', $list);
	}

	public function update(){
		$shops = new Shops();

		for( $w = 1; $w <= 7 ; $w++ ){
			$array[$w]['start'] = $_GET["w".$w."_1"] ?? "10:00";
			$array[$w]['end'] = $_GET["w".$w."_2"] ?? "22:00";

			$shops = Shops::where('week', '=', $w)->where('shop_id', Shops::$shopId)->first();

			if(is_null($shops)){
				$shops = new Shops();
			}

			$shops->open = $array[$w]['start'] ;
			$shops->close = $array[$w]['end'] ;
			$shops->week = $w ;

			$shops->save();
		}
		return $this->index();
	}
}
