<?php

namespace App\Http\Controllers\Admin\Auth;

use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;

use App\Models\Admins;
class ResetPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/admin/index';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

//        $this->middleware('auth:admin');
    }
    
    public function showLinkRequestForm(){
        return view('admin.auth.passwords.reset');
    }

    public function update(){
        if($_REQUEST["email"] != '' && !empty($_REQUEST["email"])){
            $admin = Admins::where('email',$_REQUEST["email"])->first();

            if(
                $admin != null 
              //   !hash::check($_REQUEST["password"], hash::make($_REQUEST["password"])) 
                &&
                 $_REQUEST["password"] == $_REQUEST["password_confirmation"]
            ){
                if( Hash::check($_REQUEST["password"],$admin['password'])){

                }else{
                  $admin->password = hash::make($_REQUEST["password"]);
                  $admin->save();
                echo "passwords change";
                }
                return view('admin.auth.login');
            }
        }
        return view('admin.auth.passwords.reset');
    }
}

