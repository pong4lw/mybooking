<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\RegistersUsers;

use Illuminate\Http\Request;

use App\Models\Services;
use App\Models\Service_descriptions;
use App\Models\Spaces;

use App\Models\Provieder_appoints;
use App\Models\Provieder_services;
use App\Models\Users;
use App\Models\Tickets;
use App\Models\Admins;
use App\Models\Plans;
use App\Mail\ContactMail;
use App\Models\Shops;


class StaffController extends Controller
{
	public function __construct()
	{
		//	$this->middleware('auth');
	}

	public function index(){
		return view('admin.userlist');
	}

	public function stafflist(){
		$shops = new Shops();
		$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		if($list['adminuser']->user_type == 'admin'){
			$list['staffs'] = Admins::all();
		}else{
			$list['staffs'] = Admins::where('shop_id', Shops::$shopId)->get();
		}
		
		foreach( $list['staffs'] as $k =>$u ){
			$list['staffs'][$k]['ticket'] = Tickets::where('client_id', $u['admin_id'])->where('shop_id', Shops::$shopId)->get();
		}
		return view('admin.staffsList', $list);
	}

	public function staff($id){
		$shops = new Shops();
		$staffs = new Admins();
		$list['staffs'] = $staffs->find($id);
		$adminId = Auth::id() ?? 1;
		
		$list['shoplist'] = Shops::shoplist();

		$list['adminuser'] = Admins::find($adminId);
		if($list['adminuser']->user_type == 'admin'){
			$list['skill'] = Services::all();
		}else{
			$list['skill'] = Services::where('shop_id', Shops::$shopId)->get();
		}
		

		return view('admin.staffs', $list);
	}
	
	public function staffadd(){
		$staffs = new Admins();
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);
		$list['Admins'] = $staffs->find(Auth::id());
		return view('admin.staffaddcomp');
	}
	
	public function staffaddsave(){
		$staffs = new Admins();
		$list['staffs'] = $staffs->find($id);
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		return view('admin.staffs',$list);
	}

	public function staffaddmail(){
		$email = $_REQUEST['email'];
				$adminId = Auth::id() ?? 1;

		$list['adminuser'] = Admins::find($adminId);

		if($_REQUEST['user_type'] == "staff"){
		    $name = 'staff';
		    $text = 'よろしくお願いいたします。';
   			$to = 'hiroki.hon@gmail.com';

		    var_dump(Mail::to($to)->send(new RegisterMail($name, $text)));
		}

		if($_REQUEST['user_type'] == "staff2"){

		}
	}

  public function upload(Request $request)
    {
        $this->validate($request, [
            'file' => [
                'required',
                'file',
                'image',
                'mimes:jpeg,png',
                'dimensions:min_width=120,min_height=120,max_width=400,max_height=400',
            ]
        ]);

        if ($request->file('file')->isValid([])) {
            $filename = $request->file->store('public/staff');

            $user = Admins::find($id);
            $user->avatar_filename = basename($filename);
            $user->save();

            return redirect('admin/staff')->with('success', '保存しました。');
        } else {
            return redirect()
                ->back()
                ->withInput()
                ->withErrors(['file' => '画像がアップロードされていないか不正なデータです。']);
        }
    }

	public function staffupdate($staffs_id = null){
		$staffs = new Admins();
		$shops = new Shops();

		$list['staffs'] = $staffs->find($staffs_id);

		$adminId = Auth::id() ?? 1;
		$list['adminuser'] = Admins::find($adminId);

		if($staffs_id == null){
			if($_REQUEST['name'] == ''){
				$list['staffs'] = $staffs;
				return view('admin.user',$list);
			}
			$list['staffs'] = $staffs;

		}else{
			$list['staffs'] = $staffs->where('id',$staffs_id)->where('shop_id', Shops::$shopId)->first();
		}
//		$shop_id = ;

		$list['staffs']['name'] = $_REQUEST['name'];
		$list['staffs']['email'] = $_REQUEST['email'];
		$list['staffs']['tel'] = $_REQUEST['tel'];
		$list['staffs']['address'] = $_REQUEST['address'];
		$list['staffs']['user_type'] = $_REQUEST['user_type'];
		$list['staffs']['shop_id'] = $_REQUEST['shop_id'];
        $list['staffs']['password'] = Hash::make($_REQUEST['password']);
		$list['staffs']->save();
	
			return redirect('admin/staff');
	}
}
