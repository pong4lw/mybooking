<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class StudioController extends Controller
{
    public function __construct()
    {
   //     $this->middleware('admin');
    }

	public function index(){
		$list['studio'] = Spaces::where('shop_id',Shop::$shopId);
	    return view('admin.studio', $list);
	}

	public function create(){

	    return view('admin.studio_edit',$list);
	}


	public function update(){


	    return view('admin.studio_edit',$list);
	}

}
