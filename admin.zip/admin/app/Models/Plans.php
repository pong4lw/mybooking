<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model as Eloquent;


class Plans extends Eloquent
{
    use Notifiable;

    protected $table = 'plans';
    protected $primaryKey = 'id';

    public function find_all(){
        $res = array();
    	foreach (Plans::all() as $k => $v){
    		$res[$k] = $v;
			$res[$k]['space'] = $v['space_id'];
			$res[$k]['services'] = Services::find($v->services_id);
			$res[$k]['client'] = Users::where('id', $v->client_id)->get();
			$res[$k]['provider'] = Admins::where('id',$v->provider_id)->get();
    	}
    	return $res;
    }

    public function find_by_used_day($used_at = null){
        if(is_null($used_at)){
            return false;
        }
        $plans = Plan::where('used_at', '=' ,$used_at)->get();
    }

    public function find_empty_time($staffId, $used_at = null){
        if(is_null($staffId) || is_null($used_at)){
            return false;
        }
        $plans = Plan::where('used_at', '=' ,$used_at)->get();
    }
}
