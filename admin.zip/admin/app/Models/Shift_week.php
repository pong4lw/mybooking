<?php
namespace App\Models;

use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model as Eloquent;

class Shift_week extends Eloquent
{
	use Notifiable;

	protected $table = 'shift_week';
	protected $primaryKey = 'id';

	static public function update_week($array){
		$shift_week = new Shift_week();
		$shift_week = $shift_week->where('shop_id',$array['shop_id'])->where('provider_id',$array['provider_id'])->where('week',$array['week'])->first();

		if(is_null($shift_week)){
			$shift_week = new Shift_week();
 		}

		$shift_week['open'] = $array['open'];
		$shift_week['close'] = $array['close'];
		$shift_week['space_id'] = $array['space_id'];
		$shift_week['provider_id'] = $array['provider_id'];
		$shift_week['shop_id'] = $array['shop_id'];		
		$shift_week['week'] = $array['week'];
		$shift_week->save();
	}

	static function weekArray($c,$shopId){
		$result = array();
		$weeks = Shift_week::where($c,$shopId)->get();

		foreach ($weeks as $k => $v) {
			$result[$v['week']] = $v;
		}
		return $result;
	}

}
