<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Model
 * Created by SoulMaster
 * Created at 3/25/18
 * @package \App\Models
 **/

class Model extends Eloquent
{

    protected $guarded = [];

}
