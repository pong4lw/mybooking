<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model as Eloquent;
use App\Models\Shopdsp;

class Shops extends Eloquent
{
    use Notifiable;
    protected $table = 'shops';
    protected $primaryKey = 'id';
    public static $shopId = '0';	

    public static $shopArray = array(
        '0'=> 'sample'
        ,'1'=>'学大'
        ,'2'=>'烏丸'
        ,'3'=>'豊中'
    );

   static public function shoplist(){
        return Shopdsp::all();
    }


    public function open_hours($week = 1){
    	return Shops::where('shop_id', Shops::$shopId)->where('week',$week)->first();
    }

    public function open_hours_week(){
    	$week = array();
    	for ($i = 1; $i <=7; $i++) {
	    	$hours = Shops::open_hours($i);
 			$week[$i]['open'] = $hours['open'];
 			$week[$i]['close'] = $hours['close'];
    	}
    	return $week;
    }

    static function weekArray($c,$shopId){
        $result = array();
        $weeks = Shops::where($c,$shopId)->get();

        foreach ($weeks as $k => $v) {
            $result[$v['week']] = $v;
        }
        return $result;
    }

}
