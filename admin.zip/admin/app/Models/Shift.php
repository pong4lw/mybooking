<?php
namespace App\Models;

use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model as Eloquent;
use App\Models\Shift_week;

class Shift extends Eloquent
{
	use Notifiable;

	protected $table = 'shift_day';
	protected $primaryKey = 'id';

	static function searchShift($providerId = null){
		if(is_null($providerId)){
			return false;
		}

		$shift_week = Shift_week::where('provider_id', '=', $providerId)->get();

		$shift_day = Shift_day::where('provider_id', '=', $providerId)->get();

		$week = Shift_week::weekArray('shop_id', Shops::$shopId);

		for($d = 1; $d <= date('t'); $d++){	
			$d = str_pad($d, 2, 0, STR_PAD_LEFT);
			$timestamp = strtotime(date('Y').'-'.date('m').'-'.$d );
			$w = date('w',$timestamp);
			if($w == 0){ $w =7;}

			$week[$w]['used_at'] = date('Y').'-'.date('m').'-'.$d;
			$result[date('Y').'-'.date('m').'-'.$d] = $week[$w];
		}

		foreach($shift_day as $shift){
			if(!empty($shift->used_at)){
				$day = explode('-', $shift->used_at);

				$result[$day[0].'-'.str_pad($day[1],2,0,STR_PAD_LEFT).'-'.str_pad($day[2],2,0,STR_PAD_LEFT)] = $shift;
			}
		}
		return $result;
	}

	static function find_by_id($id = 1){
		
	}
}
