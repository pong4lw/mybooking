<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
//use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model as Eloquent;

class Settings_bussiness_time extends Eloquent
{
    use Notifiable;

    protected $table = 'settings_bussiness_time';
    protected $primaryKey = 'id';



   	static function searchBussinessTime(){
		$week = Shops::weekArray('shop_id', Shops::$shopId);
		foreach ($week as $k => $w){
			$week[$k]['start'] = str_pad($w['open'], 5, 0, STR_PAD_LEFT);
			$week[$k]['end'] = str_pad($w['close'], 5, 0,  STR_PAD_LEFT);
		}

		for($d = 1; $d <= date('t'); $d++){
			$d = str_pad($d, 2, 0, STR_PAD_LEFT);
			$timestamp = strtotime(date('Y').'-'.date('m').'-'.$d );
			$w = date('w', $timestamp);
			if($w == 0){ $w = 7;}

			$week[$w]['used_at'] = date('Y').'-'.date('m').'-'.$d;
			$result[date('Y').'-'.date('m').'-'.$d] = $week[$w];
		}

		$settings_bussiness_time = Settings_bussiness_time::where('shop_id', Shops::$shopId)->get();
		foreach($settings_bussiness_time as $time){
			$time->start = str_pad($time->start, 5, 0, STR_PAD_LEFT);
			$time->end = str_pad($time->end, 5, 0, STR_PAD_LEFT);
			if(!empty($time->used_at)){
				$day = explode('-', $time->used_at);
				$result[$day[0].'-'.str_pad($day[1] ,2 ,0 ,STR_PAD_LEFT).'-'.str_pad($day[2] ,2 ,0 ,STR_PAD_LEFT)] = $time;
			}
		}

		return $result;
	}



}
